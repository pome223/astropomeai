/* Build an offline HTML reading copy and render the two Mermaid diagrams.
 * Requires Node.js, markdown-it 14, Playwright with Chromium, Mermaid 10.
 * Optional module overrides: PAPER_MARKDOWN_IT, PAPER_PLAYWRIGHT, PAPER_MERMAID.
 * No mission execution, remote browsing, or model inference occurs here.
 */
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const MarkdownIt = require(process.env.PAPER_MARKDOWN_IT || 'markdown-it');
const { chromium } = require(process.env.PAPER_PLAYWRIGHT || 'playwright');

const root = path.resolve(__dirname, '..');
const markdownPath = path.join(root, 'missionos-control-layer-paper-ja.md');
const mermaidPath = process.env.PAPER_MERMAID || require.resolve('mermaid/dist/mermaid.min.js');
const out = path.join(root, 'preview.html');
const qa = path.join(root, 'qa');
fs.mkdirSync(qa, { recursive: true });

const source = fs.readFileSync(markdownPath, 'utf8');
const diagrams = [...source.matchAll(/```mermaid\n([\s\S]*?)\n```/g)];
const diagramNames = ['figure-01-architecture', 'figure-05-cognitive-bridge'];
if (diagrams.length !== diagramNames.length) throw new Error('Unexpected Mermaid diagram count.');
diagrams.forEach((m, i) => fs.writeFileSync(path.join(root, 'assets', diagramNames[i] + '.mmd'), m[1] + '\n'));

const md = new MarkdownIt({ html: false, linkify: false, typographer: false });
const defaultFence = md.renderer.rules.fence;
md.renderer.rules.fence = (tokens, idx, options, env, self) =>
  tokens[idx].info.trim() === 'mermaid'
    ? '<div class="diagram mermaid">' + md.utils.escapeHtml(tokens[idx].content) + '</div>'
    : defaultFence(tokens, idx, options, env, self);
md.renderer.rules.table_open = () => '<div class="table-wrap"><table>\n';
md.renderer.rules.table_close = () => '</table></div>\n';

const css = `
:root{color-scheme:light;--ink:#1c2d3b;--muted:#587082;--line:#dbe3e8;--accent:#245a78}
*{box-sizing:border-box}
body{margin:0;background:#f1f4f6;color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Hiragino Kaku Gothic ProN","Yu Gothic",sans-serif;font-size:16px;line-height:1.95}
main{max-width:1010px;margin:40px auto;padding:64px 72px;background:white;border-top:5px solid var(--accent);box-shadow:0 4px 28px #19313b0b}
h1{font-size:31px;line-height:1.55;margin:0 0 12px;letter-spacing:.02em}
h1+h2{font-size:18px;line-height:1.8;color:var(--muted);font-weight:500;border:0;margin:0 0 32px;padding:0}
h2{font-size:24px;line-height:1.6;margin:55px 0 20px;border-top:1px solid var(--line);padding-top:24px}
h3{font-size:19px;line-height:1.6;margin:34px 0 14px}
p{margin:18px 0;text-align:justify;overflow-wrap:anywhere}
a{color:#176187;text-underline-offset:3px}
img{display:block;width:auto;max-width:100%;max-height:850px;margin:30px auto 12px;height:auto}
p:has(>em:first-child){font-size:13px;line-height:1.8;color:#516674;margin-top:10px}
blockquote{margin:26px 0;padding:14px 23px;border-left:4px solid #527f9a;background:#f2f6f8}
blockquote p{margin:0;font-size:17px}
.diagram{margin:24px auto;overflow-x:auto;text-align:center}
.diagram svg{max-width:100%;height:auto}
.table-wrap{width:100%;overflow-x:auto;margin:24px 0}
table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.8}
th,td{border:1px solid var(--line);padding:10px 12px;text-align:left;vertical-align:top;min-width:110px}
th{background:#eef4f7;color:#183f57}
td:first-child{font-weight:500}
code{background:#f0f3f5;padding:2px 4px;border-radius:3px;font-family:ui-monospace,Menlo,monospace;font-size:.84em;overflow-wrap:anywhere}
pre{overflow:auto;padding:16px;background:#f0f3f5}
li{margin:9px 0}
@media(max-width:680px){body{font-size:15px}main{margin:0;padding:30px 20px;box-shadow:none}h1{font-size:25px}h2{font-size:22px}h3{font-size:18px}p{text-align:left}th,td{min-width:130px}img{margin-top:22px}}
@media print{body{background:white;font-size:10.5pt}main{max-width:none;margin:0;padding:0;border:0;box-shadow:none}h1{font-size:20pt}h2{font-size:15pt}h3{font-size:12pt}img,.diagram,table{break-inside:avoid}a{color:inherit}}
`;
const initial = '<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>MissionOS 管制レイヤー 研究報告</title><style>' + css + '</style></head><body><main>' + md.render(source) + '</main></body></html>';
fs.writeFileSync(out, initial);

(async () => {
  const browser = await chromium.launch({ headless: true, ...(process.env.PAPER_BROWSER_CHANNEL ? { channel: process.env.PAPER_BROWSER_CHANNEL } : {}) });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, deviceScaleFactor: 1 });
    const errors = [];
    page.on('pageerror', e => errors.push(e.message));
    await page.goto(pathToFileURL(out).href);
    await page.addScriptTag({ path: mermaidPath });
    await page.evaluate(async () => {
      mermaid.initialize({
        startOnLoad: false, securityLevel: 'strict', theme: 'base',
        fontFamily: 'Hiragino Kaku Gothic ProN, Yu Gothic, sans-serif',
        themeVariables: { fontSize: '16px', primaryColor: '#edf3f7', primaryTextColor: '#203747', primaryBorderColor: '#617e91', lineColor: '#617e91', edgeLabelBackground: '#ffffff', background: '#ffffff' },
        flowchart: { useMaxWidth: true, htmlLabels: true, curve: 'linear', nodeSpacing: 26, rankSpacing: 38 }
      });
      await mermaid.run({ querySelector: '.mermaid' });
    });
    await page.evaluate(() => document.fonts.ready);
    const blocks = page.locator('.diagram');
    for (let i = 0; i < diagramNames.length; i++) {
      const svg = await blocks.nth(i).locator('svg').evaluate(el => el.outerHTML);
      fs.writeFileSync(path.join(root, 'assets', diagramNames[i] + '.svg'), svg + '\n');
      await blocks.nth(i).screenshot({ path: path.join(root, 'assets', diagramNames[i] + '.png') });
    }
    await page.evaluate(() => document.querySelectorAll('script').forEach(x => x.remove()));
    fs.writeFileSync(out, '<!doctype html>\n' + await page.locator('html').evaluate(x => x.outerHTML));
    const checks = await page.evaluate(() => ({
      svg_count: document.querySelectorAll('.diagram svg').length,
      broken_images: [...document.images].filter(x => !x.complete || !x.naturalWidth).map(x => x.getAttribute('src')),
      horizontal_overflow: document.documentElement.scrollWidth > innerWidth + 1,
      table_count: document.querySelectorAll('table').length,
      headings: [...document.querySelectorAll('h1,h2,h3')].map(x => x.textContent),
      external_scripts: document.querySelectorAll('script[src]').length
    }));
    checks.manuscript_sha256 = require('crypto').createHash('sha256').update(source).digest('hex');
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.screenshot({ path: path.join(qa, 'desktop-opening.png') });
    await page.locator('h3').filter({ hasText: '6.2.' }).scrollIntoViewIfNeeded();
    await page.screenshot({ path: path.join(qa, 'desktop-cognitive-bridge.png') });
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(pathToFileURL(out).href);
    await page.screenshot({ path: path.join(qa, 'mobile-opening.png') });
    checks.mobile_horizontal_overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1);
    checks.javascript_errors = errors;
    fs.writeFileSync(path.join(qa, 'render-checks.json'), JSON.stringify(checks, null, 2) + '\n');
    console.log(JSON.stringify(checks, null, 2));
    if (checks.broken_images.length || checks.horizontal_overflow || checks.mobile_horizontal_overflow || errors.length || checks.svg_count !== 2) throw new Error('Rendering checks failed.');
  } finally {
    await browser.close();
  }
})().catch(e => { console.error(e); process.exit(1); });

