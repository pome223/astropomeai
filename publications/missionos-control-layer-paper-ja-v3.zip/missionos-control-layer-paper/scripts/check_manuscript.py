"""Check portable manuscript links, citations, image identity, and Mermaid artifacts."""
from pathlib import Path
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "missionos-control-layer-paper-ja.md"
text = PAPER.read_text(encoding="utf-8")
errors = []

def check(condition, message):
    if not condition:
        errors.append(message)

references = dict(re.findall(r"^\[([^\]]+)\]:\s+(\S+)\s*$", text, re.M))
used = re.findall(r"(?<!!)\[[^\]\n]+\]\[([^\]\n]+)\]", text)
check(set(used) <= set(references), "Undefined bibliography references")
check(len(references) == 11, "Unexpected source count")
check(set(used) == set(references), "Unused source definitions")
check(all(key.startswith("m-") for key in references), "Unexpected external research citation")
table_numbers = re.findall(r"^\*\*表(\d+)\.", text, re.M)
check(table_numbers == ["1", "2", "3", "4", "5"], "Missing or nonsequential table captions")
check(text.count("```") % 2 == 0, "Unbalanced code fences")
check("\ufffd" not in text, "Unicode replacement characters")
check("/Users/" not in text and "/private/tmp/" not in text, "Nonportable workstation path in manuscript")
check(not re.search(r"\b(?:TODO|TBD|FIXME)\b", text), "Unfinished placeholder")
inline = re.findall(r"!?\[[^\]\n]*\]\(([^)\n]+)\)", text)
for url in inline:
    if url.startswith(("https://", "http://", "#")):
        continue
    check((ROOT / url.split("#")[0]).is_file(), "Missing local link: " + url)

diagrams = re.findall(r"```mermaid\n([\s\S]*?)\n```", text)
names = ["figure-01-architecture", "figure-05-cognitive-bridge"]
check(len(diagrams) == 2, "Expected two Mermaid diagrams")
for name, code in zip(names, diagrams):
    mmd = ROOT / "assets" / (name + ".mmd")
    check(mmd.exists() and mmd.read_text().strip() == code.strip(), "Stale Mermaid source: " + name)
    for ext in ("svg", "png"):
        p = ROOT / "assets" / (name + "." + ext)
        check(p.is_file() and p.stat().st_size > 100, "Missing rendered diagram: " + p.name)

downloads = json.loads((ROOT / "sources/download-manifest.json").read_text())
for entry in downloads:
    p = ROOT / entry["path"]
    check(p.exists(), "Missing downloaded source: " + entry["path"])
    if p.exists():
        check(hashlib.sha256(p.read_bytes()).hexdigest() == entry["sha256"], "Source SHA-256 mismatch: " + entry["path"])

sources = json.loads((ROOT / "sources/repository-sources.json").read_text())
for entry in sources:
    p = ROOT / entry["file"]
    check(p.exists(), "Missing repository source: " + entry["file"])
    if p.exists():
        data = p.read_bytes()
        digest = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        check(digest == entry["blob_sha"], "Git blob mismatch: " + entry["file"])

provenance = json.loads((ROOT / "sources/building-missionos-publication.json").read_text())
figure = next(x for x in provenance["figures"] if x["path"].endswith("thrust-matrix.png"))
check(hashlib.sha256((ROOT / "assets/starship-thrust-matrix.png").read_bytes()).hexdigest() == figure["sha256"], "Published matrix figure provenance mismatch")
values = provenance["historical_thrust_study"]["contact_speed_m_s"]
check(len(values) == 3 and all(len(row) == 3 for row in values), "Unexpected matrix shape")
check(all(values[i][i] < 5 for i in range(3)), "Unexpected matched-cell result")
check(all(values[i][j] > 5 for i in range(3) for j in range(3) if i != j), "Unexpected mismatched-cell result")

qa = json.loads((ROOT / "qa/render-checks.json").read_text())
check(qa.get("manuscript_sha256") == hashlib.sha256(PAPER.read_bytes()).hexdigest(), "Stale HTML rendering")
check(qa["svg_count"] == 2 and not qa["broken_images"], "Incomplete rendered document")
check(not qa["horizontal_overflow"] and not qa["mobile_horizontal_overflow"], "Page overflow")
check(not qa["javascript_errors"], "JavaScript rendering error")
report = {
    "status": "passed" if not errors else "failed",
    "manuscript_characters": len(text),
    "reference_count": len(references),
    "mermaid_diagrams": len(diagrams),
    "research_images": len(re.findall(r"!\[[^\]]*\]\(assets/", text)),
    "tables_in_preview": qa["table_count"],
    "table_numbers": table_numbers,
    "repository_source_files": len(sources),
    "checked_downloads": len(downloads),
    "errors": errors,
    "scope": "Document structure, local links, source identity and rendering only; no new experiment or raw-log revalidation."
}
(ROOT / "qa/manuscript-checks.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(report, ensure_ascii=False, indent=2))
sys.exit(bool(errors))

